package client;

import ctrl.Ctrl;

public class Client {
	public static void main(String[] args) {
		
		Ctrl user= new Ctrl();
		user.startApp();
	}
}
